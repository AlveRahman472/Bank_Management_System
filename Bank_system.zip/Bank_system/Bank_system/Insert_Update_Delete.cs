﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank_system
{
    public partial class Insert_Update_Delete : Form
    {
        public Insert_Update_Delete()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        MySqlConnection connection = new MySqlConnection("server = localhost; database = naf_bank; username = root; password=;");

        MySqlCommand command;


        private void Insert_Update_Delete_Load(object sender, EventArgs e)
        {
            populateDGV();
        }
        public void populateDGV()
        {
            string selectQuery = "SELECT * FROM customer";
            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter(selectQuery,connection);
            adapter.Fill(table);

            dataGridView_Insert_Update_Delete.DataSource = table;
        }


        private void dataGridView_Insert_Update_Delete_MouseClick(object sender, MouseEventArgs e)
        {
            textBoxCustId.Text = dataGridView_Insert_Update_Delete.CurrentRow.Cells[0].Value.ToString();
            textBoxFName.Text = dataGridView_Insert_Update_Delete.CurrentRow.Cells[1].Value.ToString();
            textBoxLName.Text = dataGridView_Insert_Update_Delete.CurrentRow.Cells[2].Value.ToString();
            textBoxStreet.Text = dataGridView_Insert_Update_Delete.CurrentRow.Cells[3].Value.ToString();
            textBoxCity.Text = dataGridView_Insert_Update_Delete.CurrentRow.Cells[4].Value.ToString();
            textBoxPhn.Text = dataGridView_Insert_Update_Delete.CurrentRow.Cells[5].Value.ToString();
            dateTimePicker1.Text = dataGridView_Insert_Update_Delete.CurrentRow.Cells[6].Value.ToString();
            textBoxEmail.Text = dataGridView_Insert_Update_Delete.CurrentRow.Cells[7].Value.ToString();

        }
        public void openConnection()
        {
            if (connection.State == ConnectionState.Closed)
            {
                connection.Open();
            }
        }

        public void closeConnection()
        {
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
        }

        public void executeMyQuery(string query)
        {
            try
            {
                openConnection();
                command = new MySqlCommand(query,connection);

                if (command.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Query Executed");
                }
                else
                {
                    MessageBox.Show("Query Not Executed");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                closeConnection();
            }
        }

        private void btn_Insert_Click(object sender, EventArgs e)
        {
           

        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
           

        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlDataReader mdr;
            string select = "SELECT * FROM customer WHERE custid  =" +textBoxCustId.Text;
            command = new MySqlCommand(select,connection);
            openConnection();
            mdr = command.ExecuteReader();

            if (mdr.Read())
            {
                textBoxFName.Text = mdr.GetString("first_name");
                textBoxLName.Text = mdr.GetString("last_name");
                textBoxStreet.Text = mdr.GetString("street");
                textBoxCity.Text = mdr.GetString("city");
                textBoxPhn.Text = mdr.GetString("phone");
                dateTimePicker1.Text = mdr.GetString("date");
                textBoxEmail.Text = mdr.GetString("email").ToString();
            }
            else
            {
                MessageBox.Show("User Not Found");
            }
            closeConnection();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            new Account_Update_delete_search().Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Main().Show();
            this.Hide();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string updateQuery = "UPDATE customer SET last_name='" + textBoxLName.Text + "',first_name='" + textBoxFName.Text + "',street='" + textBoxStreet.Text + "',city='" + textBoxCity.Text + "',phone='" + textBoxPhn.Text + "',date='" + dateTimePicker1.Text + "',email='" + textBoxEmail.Text + "' WHERE custid =" + int.Parse(textBoxCustId.Text);
            executeMyQuery(updateQuery);
            populateDGV();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string deleteQuery = "DELETE FROM customer WHERE custid  =" + int.Parse(textBoxCustId.Text);
            executeMyQuery(deleteQuery);
            populateDGV();

        }
    }
 }

