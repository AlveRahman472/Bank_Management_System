﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Drawing;

namespace Bank_system
{
    public partial class Accountcreation : Form
    {
        public Accountcreation()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        MySqlConnection con = new MySqlConnection("server = localhost; database = naf_bank; username = root; password=;");

        public object MySqlcommand { get; private set; }

        public void custid()
        {
            con.Open();
            string query = "select max(custid) from customer";
            MySqlCommand cmd = new MySqlCommand(query, con);

            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if(dr.Read())
            {
                string val = dr[0].ToString();
                if (val == "")
                {
                    label14.Text = "100";
                }

                else
                {
                    int a;

                    a = int.Parse(dr[0].ToString());
                    a = a + 1; 
                    label14.Text = a.ToString();
                }
                con.Close();
            }
                
         }
      

        private void Accountcreation_Load(object sender, EventArgs e)
        {
            custid();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
            button3.BackColor = ColorTranslator.FromHtml("#a72525");
            button4.BackColor = ColorTranslator.FromHtml("#ac5555");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
            button4.BackColor = ColorTranslator.FromHtml("#ac5555");
            button3.BackColor = ColorTranslator.FromHtml("#a72525");
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string cid, lname, fname, street, city, phn, date, email, accno, acctype, des, balan;

            cid = label14.Text;
            lname = txtlname.Text;
            fname = txtfname.Text;
            street = txtstrt.Text;
            city = txtcity.Text;
            phn = txtphn.Text;
            date = txtdate.Text;
            email = txtemail.Text;
            accno = txtaccno.Text;
            acctype = txtacctype.Text;
            des = txtdes.Text;
            balan = txtbln.Text;

            con.Open();
            MySqlCommand cmd = new MySqlCommand();
            MySqlTransaction transaction;
            transaction = con.BeginTransaction();

            cmd.Connection = con;
            cmd.Transaction = transaction;

            try
            {
                cmd.CommandText = "insert into customer(custid,last_name,first_name,street,city,phone,date,email) values('"+cid+"','"+lname+ "','" +fname+ "','" +street+ "','" +city+ "','" +phn+ "','" +date+ "','" +email+ "')";
                cmd.ExecuteNonQuery();


                cmd.CommandText = "insert into account(act_id,custid,act_type,description,balance) values('" +accno+ "','" +cid+ "','"+acctype+"','" +des+ "','" +balan+ "')";
                cmd.ExecuteNonQuery();

                transaction.Commit();
                MessageBox.Show("Record Added");
        
            }

            catch(Exception ex)
            {
                transaction.Rollback();
                MessageBox.Show(ex.ToString());
            }

            finally
            {
                con.Close();
            }
           

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }
    }
}
