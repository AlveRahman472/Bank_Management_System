﻿namespace Bank_system
{
    partial class Transfer_List
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Transfer_dataGridView = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.Transfer_dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // Transfer_dataGridView
            // 
            this.Transfer_dataGridView.BackgroundColor = System.Drawing.Color.SandyBrown;
            this.Transfer_dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Transfer_dataGridView.Location = new System.Drawing.Point(94, 117);
            this.Transfer_dataGridView.Name = "Transfer_dataGridView";
            this.Transfer_dataGridView.Size = new System.Drawing.Size(546, 233);
            this.Transfer_dataGridView.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Sitka Small", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(248, 45);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(225, 27);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = " Transfer Details";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Transfer_List
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(745, 418);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Transfer_dataGridView);
            this.Name = "Transfer_List";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Transfer_List";
            this.Load += new System.EventHandler(this.Transfer_List_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Transfer_dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView Transfer_dataGridView;
        private System.Windows.Forms.TextBox textBox1;
    }
}