﻿namespace Bank_system
{
    partial class Loan_List
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Loan_dataGridView = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.Loan_dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // Loan_dataGridView
            // 
            this.Loan_dataGridView.BackgroundColor = System.Drawing.Color.SandyBrown;
            this.Loan_dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Loan_dataGridView.Location = new System.Drawing.Point(96, 102);
            this.Loan_dataGridView.Name = "Loan_dataGridView";
            this.Loan_dataGridView.Size = new System.Drawing.Size(540, 251);
            this.Loan_dataGridView.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(283, 44);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(167, 28);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "Loan Details";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Loan_List
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(735, 401);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Loan_dataGridView);
            this.Name = "Loan_List";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Loan_List";
            this.Load += new System.EventHandler(this.Loan_List_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Loan_dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView Loan_dataGridView;
        private System.Windows.Forms.TextBox textBox1;
    }
}