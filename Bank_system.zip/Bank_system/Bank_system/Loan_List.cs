﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace Bank_system
{
    public partial class Loan_List : Form
    {
        public Loan_List()
        {
            InitializeComponent();
        }

        private void Loan_List_Load(object sender, EventArgs e)
        {
            Loan_dataGridView.DataSource = GetLoan_List();
        }
        private DataTable GetLoan_List()
        {

            DataTable dtLoan = new DataTable();

            string connString = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;

            using (MySqlConnection con = new MySqlConnection(connString))
            {
                using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM loan", con))
                {
                    con.Open();
                    MySqlDataReader reader = cmd.ExecuteReader();
                    dtLoan.Load(reader);
                }

            }
            return dtLoan;
        }
    }
}
