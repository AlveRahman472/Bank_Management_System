﻿using System;
using System.Windows.Forms;

namespace Bank_system
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int count;
        private void Form1_Load(object sender, EventArgs e)
        {
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username, password;

            username = txtuser.Text;
            password = txtpass.Text;

            count = count + 1;

            if(count > 3)
            {
                MessageBox.Show("System has been Blocked");
                Application.Exit();
            }

            if (username == "" && password == "")
            {
                label4.Text = "Blank not be Allowed";
            }
            else if (username.Length >= 10 && password.Length >= 10)
            {
                label4.Text = "Only 10 Character Allowed";
            }

            else
            {
                if (username == "Naznin" && password == "321")
                {
                    //label4.Text = "Login Successfully";

                    ProgressBar pr = new ProgressBar();
                    this.Hide();
                    pr.Show();
                }
                else
                {
                    label4.Text = "Invalid Login and Password";
                    txtuser.Clear();
                    txtpass.Clear();
                    txtuser.Focus();
                }
            }


        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label4.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
