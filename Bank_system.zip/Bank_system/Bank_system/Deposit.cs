﻿using Bank_system;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank_system
{
    public partial class Deposit : Form
    {
        public Deposit()
        {
            InitializeComponent();
        }
        MySqlConnection con = new MySqlConnection("server = localhost; database = naf_bank; username = root; password =;");
        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                con.Open();
                string str = "select *from account where act_id = '"+txtacc.Text+"'";
                MySqlCommand cmd = new MySqlCommand(str, con);

                MySqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    txtbaln.Text = rd[4].ToString();

                }

            }

            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string accno, date;
            double balance, deposit;

            accno = txtacc.Text;
            date = txtdate.Text;
            balance = double.Parse(txtbaln.Text);
            deposit = double.Parse(txtdep.Text);

            

            con.Open();
            MySqlCommand cmd = new MySqlCommand();
            MySqlTransaction transaction;
            transaction = con.BeginTransaction();

            cmd.Connection = con;
            cmd.Transaction = transaction;

            try
            {
                cmd.CommandText = "update account set balance = balance + '"+ deposit + "' where act_id = '"+ accno + "'";
                cmd.ExecuteNonQuery(); 


                cmd.CommandText = "insert into transaction(acct_id,date,balance,deposit) values('" + accno + "','" + date + "','" + balance + "','" + deposit + "')";
                cmd.ExecuteNonQuery();

                transaction.Commit();
                MessageBox.Show("Transaction Successfully");

            }

            catch (Exception ex)
            {
                transaction.Rollback();
                MessageBox.Show(ex.ToString());
            }

            finally
            {
                con.Close();
            }

        }

        private void Deposit_Load(object sender, EventArgs e)
        {
            
        }
    }
}
