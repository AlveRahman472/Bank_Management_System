﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank_system
{
    public partial class Account_Update_delete_search : Form
    {
        public Account_Update_delete_search()
        {
            InitializeComponent();
        }

        MySqlConnection connection = new MySqlConnection("server = localhost; database = naf_bank; username = root; password=;");

        MySqlCommand command;

        private void Account_Update_delete_search_Load(object sender, EventArgs e)
        {
            populateDGV();
        }

        public void populateDGV()
        {
            string selectQuery = "SELECT * FROM account";
            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter(selectQuery, connection);
            adapter.Fill(table);

            dataGridViewAccount.DataSource = table;
        }

        private void dataGridViewAccount_MouseClick(object sender, MouseEventArgs e)
        {
            textBoxCustId.Text = dataGridViewAccount.CurrentRow.Cells[0].Value.ToString();
            textBoxActId.Text = dataGridViewAccount.CurrentRow.Cells[1].Value.ToString();
            textBoxActType.Text = dataGridViewAccount.CurrentRow.Cells[2].Value.ToString();
            textBoxDes.Text = dataGridViewAccount.CurrentRow.Cells[3].Value.ToString();
            textBoxBlnc.Text = dataGridViewAccount.CurrentRow.Cells[4].Value.ToString();
        }
        public void openConnection()
        {
            if (connection.State == ConnectionState.Closed)
            {
                connection.Open();
            }
        }

        public void closeConnection()
        {
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
        }
        public void executeMyQuery(string query)
        {
            try
            {
                openConnection();
                command = new MySqlCommand(query, connection);

                if (command.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Query Executed");
                }
                else
                {
                    MessageBox.Show("Query Not Executed");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                closeConnection();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string updateQuery = "UPDATE account SET act_id='" + textBoxActId.Text + "',custid='" + textBoxCustId.Text + "',act_type='" + textBoxActType.Text + "',description='" + textBoxDes.Text + "',balance='" + textBoxBlnc.Text + "' WHERE custid =" + int.Parse(textBoxCustId.Text);
            executeMyQuery(updateQuery);
            populateDGV();
        }

        private void btn_Delelte_Click(object sender, EventArgs e)
        {
            string deleteQuery = "DELETE FROM account WHERE custid  =" + int.Parse(textBoxCustId.Text);
            executeMyQuery(deleteQuery);
            populateDGV();
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            MySqlDataReader mdr;
            string select = "SELECT * FROM account WHERE custid  =" + textBoxCustId.Text;
            command = new MySqlCommand(select, connection);
            openConnection();
            mdr = command.ExecuteReader();

            if (mdr.Read())
            {
                textBoxActId.Text = mdr.GetString("act_id");
                textBoxCustId.Text = mdr.GetString("custid");
                textBoxActType.Text = mdr.GetString("act_type");
                textBoxDes.Text = mdr.GetString("description");
                textBoxBlnc.Text = mdr.GetString("balance").ToString();
            }
            else
            {
                MessageBox.Show("User Not Found");
            }
            closeConnection();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            new Insert_Update_Delete().Show();
            this.Hide();
        }
    }
}
