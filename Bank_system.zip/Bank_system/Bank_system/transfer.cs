﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Bank_system
{
    public partial class transfer : Form
    {
        public transfer()
        {
            InitializeComponent();
        }

        MySqlConnection con = new MySqlConnection("server = localhost; database = naf_bank; username = root; password =;");
        private void button1_Click(object sender, EventArgs e)
        {
            string faccno, toaccno, date;
            double baln;

            faccno = txtfrmacc.Text;
            toaccno = txttoacc.Text;
            date = txtdate.Text;
            baln = double.Parse(txtamt.Text);

            con.Open();
            MySqlCommand cmd = new MySqlCommand();
            MySqlTransaction transaction;
            transaction = con.BeginTransaction();

            cmd.Connection = con;
            cmd.Transaction = transaction;

            try
            {
                cmd.CommandText = "update account set balance = balance - '" + baln + "' where act_id = '" + faccno + "'";
                cmd.ExecuteNonQuery();


                cmd.CommandText = "update account set balance = balance + '" + baln + "' where act_id = '" + toaccno + "'";
                cmd.ExecuteNonQuery();



                cmd.CommandText = "insert into transfer(from_acc,to_acc,date,amount) values('" + faccno + "','" + toaccno + "','" + date + "','" + baln + "')";
                cmd.ExecuteNonQuery();

                transaction.Commit();
                MessageBox.Show("Transaction Successfully");

            }

            catch (Exception ex)
            {
                transaction.Rollback();
                MessageBox.Show(ex.ToString());
            }

            finally
            {
                con.Close();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
