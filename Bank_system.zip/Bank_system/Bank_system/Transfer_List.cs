﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace Bank_system
{
    public partial class Transfer_List : Form
    {
        public Transfer_List()
        {
            InitializeComponent();
        }

        private void Transfer_List_Load(object sender, EventArgs e)
        {
            Transfer_dataGridView.DataSource = GetTransfer_List();
        }
        private DataTable GetTransfer_List()
        {

            DataTable dtTransfer = new DataTable();

            string connString = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;

            using (MySqlConnection con = new MySqlConnection(connString))
            {
                using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM transfer", con))
                {
                    con.Open();
                    MySqlDataReader reader = cmd.ExecuteReader();
                    dtTransfer.Load(reader);
                }

            }
            return dtTransfer;
        }

    }
}
