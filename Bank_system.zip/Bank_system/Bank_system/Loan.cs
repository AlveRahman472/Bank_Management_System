﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank_system
{
    public partial class Loan : Form
    {
        public Loan()
        {
            InitializeComponent();
        }
        MySqlConnection con = new MySqlConnection("server = localhost; database = naf_bank; username = root; password =;");

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string str = "select *from account where act_id = '" + txtacc.Text + "'";
                MySqlCommand cmd = new MySqlCommand(str, con);

                MySqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    txtbaln.Text = rd[4].ToString();

                }

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string accno, date, lntype;
            double balance, lnamount;

            accno = txtacc.Text;
            date = txtdate.Text;
            lntype = LnType.Text;
            balance = double.Parse(txtbaln.Text);
            lnamount = double.Parse(txtlnamt.Text);
            



            con.Open();
            MySqlCommand cmd = new MySqlCommand();
            MySqlTransaction transaction;
            transaction = con.BeginTransaction();

            cmd.Connection = con;
            cmd.Transaction = transaction;

            try
            {
                cmd.CommandText = "update account set balance = balance + '" + lnamount + "' where act_id = '" + accno + "'";
                cmd.ExecuteNonQuery();


                cmd.CommandText = "insert into loan(acc_id ,date,balance,loan_type,loan_amount) values('" + accno + "','" + date + "','" + balance + "','" + LnType + "', '"+ lnamount + "')";
                cmd.ExecuteNonQuery();

                transaction.Commit();
                MessageBox.Show("Transaction Successfully");

            }

            catch (Exception ex)
            {
                transaction.Rollback();
                MessageBox.Show(ex.ToString());
            }

            finally
            {
                con.Close();
            }

        }

        private void Loan_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
 }
    

