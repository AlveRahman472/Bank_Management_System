﻿using System;
using System.Windows.Forms;

namespace Bank_system
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Accountcreation account = new Accountcreation();
            account.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Deposit depo = new Deposit();
           
            depo.Show();
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            transfer trn = new transfer();
            trn.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Withdraw witd = new Withdraw();
            witd.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Loan ln = new Loan();
            ln.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
           Customer_List cust = new Customer_List();
            cust.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Customer_account act = new Customer_account();
            act.Show();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            new Insert_Update_Delete().Show();
            this.Hide();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Transaction tran = new Transaction();
            tran.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Transfer_List tran_list = new Transfer_List();
            tran_list.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Loan_List ln_list = new Loan_List();
            ln_list.Show();
        }
    }
}
