﻿using System;
using System.Windows.Forms;

namespace Bank_system
{
    public partial class ProgressBar : Form
    {
        public ProgressBar()
        {
            InitializeComponent();
        }

        private void ProgressBar_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            progressBar1.Value = progressBar1.Value + 1;

            if(progressBar1.Value >=99)
            {
                Main m = new Main();
                this.Hide();
                m.Show();

                timer1.Enabled = false;
                progressBar1.Value = progressBar1.Value + 1;
            }
        }
    }
}
