﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Bank_system
{
    public partial class Withdraw : Form
    {
        public Withdraw()
        {
            InitializeComponent();
        }

        MySqlConnection con = new MySqlConnection("server = localhost; database = naf_bank; username = root; password =;");
        private void Withdraw_Load(object sender, EventArgs e)
        {

           


        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                con.Open();
                string str = "select *from account where act_id = '" + txtacc.Text + "'";
                MySqlCommand cmd = new MySqlCommand(str, con);

                MySqlDataReader rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    txtbaln.Text = rd[4].ToString();

                }

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string accno, date;
            double balance, withdraw;

            accno = txtacc.Text;
            date = txtdate.Text;
            balance = double.Parse(txtbaln.Text);
            withdraw = double.Parse(txtwitd.Text);



            con.Open();
            MySqlCommand cmd = new MySqlCommand();
            MySqlTransaction transaction;
            transaction = con.BeginTransaction();

            cmd.Connection = con;
            cmd.Transaction = transaction;

            try
            {
                cmd.CommandText = "update account set balance = balance - '" + withdraw + "' where act_id = '" + accno + "'";
                cmd.ExecuteNonQuery();


                cmd.CommandText = "insert into transaction(acct_id,date,balance,withdraw) values('" + accno + "','" + date + "','" + balance + "','" + withdraw + "')";
                cmd.ExecuteNonQuery();

                transaction.Commit();
                MessageBox.Show("Transaction Successfully");

            }

            catch (Exception ex)
            {
                transaction.Rollback();
                MessageBox.Show(ex.ToString());
            }

            finally
            {
                con.Close();
            }

        }
    }
}
